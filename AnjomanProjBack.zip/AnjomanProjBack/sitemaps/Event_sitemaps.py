
from django.contrib.sitemaps import Sitemap 
from frontEnd.models import Event, division, Article


class Event_Sitemap(Sitemap):
    def items(self): 
        return Event.objects.all() 
        
    def lastmod(self, obj): 
        return obj.lastedit_date
    

    def priority(self, obj):
        # Customize priority based on Event criteria if needed
        return 0.9  # Example custom priority


class category_Sitemap(Sitemap):
    def items(self): 
        return division.objects.all() 
        
    def lastmod(self, obj): 
        return obj.lastedit_date
    

    def priority(self, obj):
        # Customize priority based on Event criteria if needed
        return 0.8  # Example custom priority


class article_Sitemap(Sitemap):
    def items(self): 
        return Article.objects.all()
        
    def lastmod(self, obj): 
        return obj.date

    def priority(self, obj):
        # Customize priority based on article criteria if needed
        return 0.7  # Example custom priority

