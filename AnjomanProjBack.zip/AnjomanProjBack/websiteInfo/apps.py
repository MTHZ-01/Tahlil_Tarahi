from django.apps import AppConfig


class WebsiteinfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'websiteInfo'
