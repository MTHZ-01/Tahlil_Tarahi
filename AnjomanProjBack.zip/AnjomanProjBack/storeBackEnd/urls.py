from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from django.urls import include, path, re_path
from payment import views as pv
from websiteInfo import views as wv
from django.views.generic import TemplateView
from API.sendEmail.views import EmailAPIView
from django.contrib.sitemaps.views import sitemap
from sitemaps.Event_sitemaps import *

sitemaps = {
    "Event": Event_Sitemap,
    "category": category_Sitemap,
    "article": article_Sitemap,  # Add the article sitemap to the dictionary
}

handler404 = "frontEnd.views.handler404"
urlpatterns = [
    path(
        "sitemap.xml",
        sitemap,
        {"sitemaps": sitemaps},
        name="django.contrib.sitemaps.views.sitemap",
    ),
    
    path("API/send_email/", EmailAPIView.as_view()),
    path("getAboutInfo", wv.getAboutInfo),
    path("", include("reactui.urls")),
    path("shoppingCart", include("reactui.urls")),
    path("shoppingCart/", include("reactui.urls")),
    path("ShoppingCart", include("reactui.urls")),
    path("ShoppingCart/", include("reactui.urls")),
    path("paymentSuccess", include("reactui.urls")),
    path("account", include("reactui.urls")),
    path("SignUp", include("reactui.urls")),
    path("SignUp/", include("reactui.urls")),
    path("Login", include("reactui.urls")),
    path("Login/", include("reactui.urls")),
    path("404/", include("reactui.urls")),
    path("404", include("reactui.urls")),
    re_path(r"^Events/(?P<event_name>[\w\s]+)", include("reactui.urls")),
    re_path(r"^Events/(?P<event_name>[\w\s]+)/?", include("reactui.urls")),
    re_path(r"^articles/(?P<event_name>[\w\s]+)/?", include("reactui.urls")),
    re_path(r"^articles/(?P<event_name>[\w\s]+)", include("reactui.urls")),
    re_path(r"^category/(?P<event_name>[\w\s]+)/?", include("reactui.urls")),
    re_path(r"^category/(?P<event_name>[\w\s]+)", include("reactui.urls")),
    re_path(r"^category/همه/(?P<event_name>[\w\s]+)", include("reactui.urls")),
    re_path(r"^category/همه/(?P<event_name>[\w\s]+)/?", include("reactui.urls")),
    re_path(r"^callBack/(?P<event_name>[\w\s-]+)", include("reactui.urls")),
    re_path(r"^callBack/200/(?P<event_name>[\w\s-]+)", include("reactui.urls")),
    re_path(r"^callBack/101/(?P<event_name>[\w\s-]+)", include("reactui.urls")),
    re_path(r"^callBack/199/(?P<event_name>[\w\s-]+)", include("reactui.urls")),
    path("admin/", admin.site.urls),  # admin site
    path("admin", admin.site.urls),  # admin site
    path("digitalAssets/", include("frontEnd.urls")),
    path("pay", pv.pay, name="pay"),
    path("pay/", pv.pay, name="pay"),
    re_path(r"^verify/(?P<event_name>[\w\s]+)", pv.verify),
    re_path(r"^verify/(?P<event_name>[\w\s]+)/", pv.verify),
    re_path(r"^verify.", pv.verify),
    path("webInfo/", include("websiteInfo.urls")),
    path('mysql/', include('mysql_app.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
