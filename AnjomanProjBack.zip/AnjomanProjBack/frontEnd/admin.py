from django.contrib import admin
from django.utils.html import format_html

# Register your models here.
from frontEnd.models import *


class feturesInline(admin.StackedInline):
    model = fetures
    extra = 0


class specsInline(admin.StackedInline):
    model = Specs
    extra = 0


class imageInline(admin.StackedInline):
    model = eventImage
    extra = 0


from django.utils.html import format_html
from django.utils.timezone import localtime


from django.utils.html import format_html
from django.utils.timezone import localtime


class eventAdmin(admin.ModelAdmin):
    inlines = [feturesInline, specsInline, imageInline]
    list_display = ["event_summary"]

    def event_summary(self, obj):
        image_url = obj.GetFirstImage() or "/static/admin/img/default-image.png"
        title = obj.title or "بدون عنوان"
        last_edit = localtime(obj.lastedit_date).strftime("%Y-%m-%d %H:%M")
        division = (
            obj.division.title if hasattr(obj.division, "title") else str(obj.division)
        )
        sub_div = f" / {obj.subDivision.title}" if obj.subDivision else ""
        is_fantastic = (
            '<span style="color:#1976d2;">✔</span>'
            if obj.isFantastic
            else '<span style="color:#d32f2f;">✖</span>'
        )

        return format_html(
            f"""
            <div style="
                display: flex;
                align-items: flex-start;
                gap: 10px;
                padding: 10px;
                background: #ffffff;
                border-radius: 8px;
                box-shadow: 0 1px 4px rgba(0,0,0,0.08);
                border: 1px solid #e3f2fd;
                max-width: 360px;
                font-family: 'Segoe UI', sans-serif;
            ">
                <img src="{image_url}"
                     style="width: 60px; height: 60px; object-fit: cover; border-radius: 6px; border: 1px solid #bbdefb;"
                     onerror="this.src='/static/admin/img/default-image.png'"/>
                <div style="flex: 1;">
                    <div style="font-weight: 600; color: #1976d2; font-size: 14px; margin-bottom: 4px;">
                        {title}
                    </div>
                    <div style="font-size: 12px; color: #555;">
                        🕒 آخرین ویرایش: {last_edit}
                    </div>
                    <div style="font-size: 12px; color: #555;">
                        📂 دسته: {division}{sub_div}
                    </div>
                    <div style="font-size: 12px; color: #555;">
                        👥 ظرفیت: {obj.max_signUps} نفر
                    </div>
                    <div style="font-size: 12px; color: #555;">
                        🌟 شگفت‌انگیز: {is_fantastic}
                    </div>
                </div>
            </div>
            """
        )


class eventInline(admin.StackedInline):
    model = Event
    inlines = [feturesInline, specsInline]
    extra = 0


class divisionAdmin(admin.ModelAdmin):
    inlines = [eventInline]


class subDivisionAdmin(admin.ModelAdmin):
    inlines = [eventInline]


@admin.action(description="تغییر وضعیت به ارسال شده")
def resolve(modeladmin, request, queryset):
    queryset.update(status="F")


@admin.action(description="تغییر وضعیت به لغو شده")
def cancled(modeladmin, request, queryset):
    queryset.update(status="F")


class EventsInOrderInline(admin.StackedInline):
    model = EventsInOrder
    extra = 0


class OrdAdmin(admin.ModelAdmin):
    model = Ord

    list_display = ["user", "status"]
    inlines = [EventsInOrderInline]
    ordering = ["user"]
    actions = [resolve]


class ordInline(admin.StackedInline):
    model = giveOrd
    extra = 0


class commentInline(admin.StackedInline):
    model = comment
    extra = 0


class eventInlineForProf(admin.StackedInline):
    verbose_name = "رویدادات خریداری شده:"
    verbose_name_plural = "رویدادات خریداری شده:"

    model = eventToProfwhore
    extra = 0


class ProfileAdmin(admin.ModelAdmin):
    inlines = [ordInline, commentInline, eventInlineForProf]
    model = profile
    list_display = ["image_preview"]

    def image_preview(self, obj):
        return format_html(
            f'<div style="width:100%"> <div style="direction:rtl; justify-content: end !important;align-items: start;display: flex;flex-direction: column;background: white;border-radius: 10px;padding: 18px;box-shadow: 2px 2px 5px black; "> <p style="color: #5c5c5c; font-size: 17px;  font-weight: 700">نام: {obj.firstName}</p> <p style="color: #5c5c5c; font-size: 17px;  font-weight: 700">نام خانوادگی: {obj.lastName}</p> <p style="color: #e26464; font-size: 17px;     font-weight: 300;"></p> </div></div>'
        )


class ArticleAdmin(admin.ModelAdmin):
    # Customize list display
    list_display = ("header", "date", "publish", "image")
    list_filter = ("publish", "date")
    search_fields = ("header", "article")
    ordering = ("publish", "-date")  # Unpublished first, then newest date

    # Admin actions
    actions = ["publish_articles", "reject_articles"]

    def publish_articles(self, request, queryset):
        """Set publish=True for selected articles."""
        updated = queryset.update(publish=True)
        self.message_user(request, f"{updated} مقاله با موفقیت منتشر شد.")

    publish_articles.short_description = "انتشار مقالات انتخاب‌شده"

    def reject_articles(self, request, queryset):
        """Delete selected articles."""
        deleted = queryset.delete()
        self.message_user(request, f"{deleted[0]} مقاله با موفقیت رد و حذف شد.")

    reject_articles.short_description = "رد و حذف مقالات انتخاب‌شده"


# admin.site.register(pictures)
# admin.site.register(serverSideCookie)
admin.site.register(logo)
# admin.site.register(mainTableFirstPic)
# admin.site.register(mainSecond)
# admin.site.register(mainThird)
# admin.site.register(registeredUser)
# admin.site.register(Ord, OrdAdmin)
admin.site.register(division)
admin.site.register(profile, ProfileAdmin)
admin.site.register(subDivision)
admin.site.register(Slider)
admin.site.register(Event, eventAdmin)
admin.site.register(News)


@admin.register(NewsComment)
class NewsCommentAdmin(admin.ModelAdmin):
    list_display = ("user", "news", "date", "approved")
    list_filter = ("news", "approved")
    search_fields = ("user__username", "news__title")
    actions = ["publish_comments", "reject_comments"]

    def publish_comments(self, request, queryset):
        updated = queryset.update(approved=True)
        self.message_user(request, f"{updated} comment(s) successfully published.")
    publish_comments.short_description = "Publish selected comments"

    def reject_comments(self, request, queryset):
        updated = queryset.update(approved=False)
        self.message_user(request, f"{updated} comment(s) successfully rejected.")
    reject_comments.short_description = "Reject selected comments"
    

@admin.register(EventRegister)
class EventRegisterAdmin(admin.ModelAdmin):
    list_display = ("user", "event", "date_registered")
    list_filter = ("event", "date_registered")
    search_fields = ("user__username", "event__title")


# Register Article with custom admin
admin.site.register(Article, ArticleAdmin)
