import jwt
from django.shortcuts import render, redirect
from frontEnd.models import *
from django.http import JsonResponse
from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate, user_logged_in, logout
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt, ensure_csrf_cookie, csrf_protect
import requests
import json
import random
import http
from websiteInfo.models import defaultEmail
from storeBackEnd.settings import BASE_URL
from django.views.decorators.http import *
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth.hashers import make_password
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.core.mail import EmailMessage

def create_jwt(user_id):
    payload = {
        "user_id": user_id,
        "exp": datetime.datetime.utcnow() + datetime.timedelta(days=7),  # 7 days
        "iat": datetime.datetime.utcnow(),
    }
    token = jwt.encode(payload, settings.SECRET_KEY, algorithm="HS256")
    return token


def verify_jwt(token):
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        return payload
    except jwt.ExpiredSignatureError:
        return None  # Token expired
    except jwt.InvalidTokenError:
        return None  # Invalid token


def get_authenticated_user(request):
    auth_header = request.META.get("HTTP_AUTHORIZATION", "")
    if not auth_header.startswith("Bearer "):
        return None
    token = auth_header.split(" ")[1]
    payload = verify_jwt(token)
    if not payload:
        return None
    from django.contrib.auth.models import User

    try:
        return User.objects.get(id=payload["user_id"])
    except User.DoesNotExist:
        return None


@csrf_exempt
@require_GET
def get_current_user(request):
    user = get_authenticated_user(request)
    if not user:
        return JsonResponse({"status": "no", "message": "Unauthorized"}, status=401)
    return JsonResponse({"status": "ok", "userId": user.id})


def duplicateEliminator(lst):
    lstRefined = []
    for i in lst:
        if i not in lstRefined:
            lstRefined.append(i)
    return lstRefined


def getLogo(request):
    l = logo.objects.all()[0]

    return JsonResponse({"imgSrc": request.build_absolute_uri(l.logo.url)})


@csrf_exempt
@require_GET
def getevents(request):
    events = Event.objects.all()
    specs = Specs.objects.all()
    features = fetures.objects.all()
    divisions = division.objects.all()
    sub_divisions = subDivision.objects.all()
    images = eventImage.objects.all()


    data = [
        {
            "eventId": event.id,
            "title": event.title,
            "introduction": event.introduction,
            "imgUrl": (
                request.build_absolute_uri(images.filter(p=event)[0].img.url)
                if images.filter(p=event).exists()
                else ""
            ),
            "eventImgUrl": [
                request.build_absolute_uri(img.img.url)
                for img in images.filter(p=event)
            ],

            "features": [str(feat) for feat in features.filter(Prod=event)],
            "specifics": [str(spec) for spec in specs.filter(Prod=event)],
            "divisions": event.division.name,
            "subDivisions": str(event.subDivision) if event.subDivision else "",
            "djangoId": event.id,
            "isFantastic": event.isFantastic,
            "registrationCount": EventRegister.objects.filter(event=event).count(),
            "max_signUps": event.max_signUps,
        }
        for event in events
    ]

    return JsonResponse({"EventData": data})


def getDivisions(request):
    d = division.objects.all()

    data = [str(i) for i in d]

    return JsonResponse({"status": 200, "data": data})


def getDivisionsWithImg(request):
    d = division.objects.all()

    data = [
        {"name": str(i), "imgUrl": request.build_absolute_uri(i.img.url)} for i in d
    ]

    return JsonResponse({"status": 200, "data": data})


@csrf_exempt
def getSlider(request):
    s = Slider.objects.all()

    return JsonResponse(
        {
            "status": "success",
            "data": [
                {
                    "img": request.build_absolute_uri(i.img.url),
                    "route": (
                        f"category/{i.category}"
                        if i.category != None
                        else f"Events/{i.Prod.title}"
                    ),
                }
                for i in s
            ],
        }
    )


@csrf_exempt
def searchevents(request):
    searchQuerry = ""

    if request.GET.get("searchQuerry"):
        searchQuerry = request.GET.get("searchQuerry")

    if searchQuerry == "":
        return JsonResponse({"status": "url_Err"})

    p = Event.objects.filter(title__icontains=searchQuerry)
    f = fetures.objects.all()
    s = Specs.objects.all()
    imgInline = eventImage.objects.all()
    dataV2 = [
        {
            "title": p[i].title,
            "introduction": p[i].introduction,
            "imgUrl": (
                list(
                    map(
                        lambda x: request.build_absolute_uri(x.img.url),
                        filter(lambda x: x.p.id == p[i].id, imgInline),
                    )
                )[0]
                if len(
                    list(
                        map(
                            lambda x: request.build_absolute_uri(x.img.url),
                            filter(lambda x: x.p.id == p[i].id, imgInline),
                        )
                    )
                )
                != 0
                else ""
            ),
            "eventImgUrl": list(
                map(
                    lambda x: request.build_absolute_uri(x.img.url),
                    filter(lambda x: x.p.id == p[i].id, imgInline),
                )
            ),
            "features": list(
                map(lambda x: str(x), filter(lambda x: x.Prod.id == p[i].id, f))
            ),
            "specifics": list(
                map(lambda x: str(x), filter(lambda x: x.Prod.id == p[i].id, s))
            ),
            "divisions": p[i].division.name,
            "subDivisions": str(p[i].subDivision),
            "djangoId": p[i].id,
        }
        for i in range(len(p))
    ]

    return JsonResponse({"Value": dataV2})


@csrf_exempt
def getAddress(request):
    options = json.loads(request.body)

    url = (
        f"https://api.neshan.org/v5/reverse?lat={options['lat']}&lng={options['longt']}"
    )

    info = requests.get(
        url,
        headers={
            "Api-Key": "service.b97f16d6446a41a19f13523dd5bdf6c2",
        },
    )
    info = info.json()

    return JsonResponse({"data": info})


@csrf_exempt
def searchLocations(request):
    body = json.loads(request.body)

    info = requests.get(
        f"https://api.neshan.org/v1/search?term={body['querry']}&lat={body['center']['latitude']}&lng={body['center']['longitude']}",
        headers={
            "Api-Key": "service.b97f16d6446a41a19f13523dd5bdf6c2",
        },
    )

    info = info.json()

    return JsonResponse({"locations": info})


@csrf_exempt
def getDivisionRelevency(request):
    d = json.loads(request.body)

    subD = subDivision.objects.all()

    p = Event.objects.all()

    divisedevents = list(
        filter(
            lambda x: str(x.division) == d["divisionName"]
            and str(x.subDivision) != "None",
            p,
        )
    )

    if len(divisedevents) == 0:
        return JsonResponse({"data": []})
    else:
        return JsonResponse(
            {
                "data": duplicateEliminator(
                    list(map(lambda x: x.subDivision.name, divisedevents))
                )
            }
        )


@csrf_exempt
def getCity(request):
    try:
        states = requests.get("https://app.krch.ir/v1/get_state").json()["objects"][
            "state"
        ]
        cities = requests.get("https://app.krch.ir/v1/get_city").json()["objects"][
            "city"
        ]

        cityStates = []

        for city in cities:
            for state in states:
                if city["state_no"] == state["no"]:
                    cityStates.append(
                        {
                            "label": f"استان {state['name']} شهر {city['name']}",
                            "id": city["no"],
                        }
                    )
                    break

        return JsonResponse({"states": cityStates})
    except:
        return JsonResponse({"error": 199})


def sendSMS(verCode):
    print(verCode)
    try:
        conn = http.client.HTTPSConnection("api.sms.ir")
        payload = json.dumps(
            {
                "mobile": "09025179201",
                "templateId": 251904,
                "parameters": [{"name": "contacts", "value": verCode}],
            }
        )
        print("we are here")
        headers = {
            "Content-Type": "application/json",
            "Accept": "text/plain",
            "x-api-key": "jmBjxmKsiLS0tLVfdZHIszrmtZdCYCgTrN298rTdh0pDqWWq",
        }
        conn.request("POST", "/v1/send/verify", payload, headers)
        res = conn.getresponse()
        data = res.read()
        print(data.decode("utf-8"))
    except Exception as e:
        print(e)
    # conn = http.client.HTTPSConnection("api.sms.ir")
    # payload = ''
    # headers = {
    # 'PageSize': '2',
    # 'X-API-KEY': 'gOHukbaatetQY6hhgnryk3K68vbSyJ5nWLU0MqjPycy4b4mwke8lx3lriKwGkZUA'
    # }
    # conn.request("GET", "/v1/line", payload, headers)
    # res = conn.getresponse()
    # data = res.read()
    # print(data.decode("utf-8"))


# @login_required(login_url=("Login"))
@csrf_exempt
def submitBuy(request):

    try:
        data = json.loads(request.body)
        print("data data data data ", data)
        print("data data data data ", data["verCode"])

        verCode = data["verCode"]
        print("verCode verCode verCode verCode verCode verCode", verCode)

        vers = list(
            filter(lambda x: x.key == verCode, GenerateVeriifyKeyCode.objects.all())
        )
        verkeys = list(map(lambda x: x.key, vers))
        print("ver ver ver ver ver ver ver ver ver ver => ", verkeys)

        if len(verkeys) == 0:
            print(
                f"Found no verCode: verCodeFromFront => {verCode} /n verCodeFromDjango => {verkeys}"
            )
            return JsonResponse(
                {"status": 101, "ERR": "Not submitted, no such verCode!"}
            )
        else:
            verToBeDeleted = vers[0]

        userId = data["userId"]
        cityId = data["cityId"]
        postalCode = data["postalCode"]
        address = data["address"]
        eventsInOrder = data["eventsInOrder"]

        u = User.objects.get(id=userId)
        p = list(filter(lambda x: x.user.id == userId, list(profile.objects.all())))[0]

        o = Ord.objects.create(
            user=u,
            cityId=f"آدرس: {address}",
            postalCode=postalCode,
            cityAndStateName=f"استان و شهر: {cityId['label']}",
            status="p",
        )

        content = []
        go = giveOrd.objects.create(order=o, profile=p)

        content.append(f"شماره همراه (نام کاربری) :{u.username}")
        content.append(f"مشتری جناب آقای/خانم  :{p.firstName + p.lastName}")
        content.append(f"شهر و استان {p.firstName + p.lastName} : {cityId['label']}")
        content.append(f"آدرس {p.firstName + p.lastName} : {address}")
        content.append(f"کد پستی {p.firstName + p.lastName} : {postalCode}")
        content.append("")
        content.append("")
        print("!!!!!!!!!!!!!!!!", eventsInOrder)

        for event in eventsInOrder:
            djangoId = event["djangoId"]
            rawEvent = Event.objects.get(id=djangoId)

            eventToAdd = Event.objects.get(id=event["djangoId"])
            pTop = eventToProfwhore.objects.create(prof=p, event=eventToAdd)
            pTop.save()
            content.append(f"رویداد شماره ی----- {eventsInOrder.index(event) + 1}")
            content.append(f"نام رویداد : {eventToAdd.title}")
            content.append(f"کد رویداد : {eventToAdd.EventCode}")

            content.append("")

        print(p)

        email = list(defaultEmail.objects.all())[-1]

        EmailString = ""

        for item in content:
            EmailString += f"-{item}\n"

        print(f"%%%%%%%%%%%%%%%%%%%%%%%Content%%%%%%%%%%%%%%%%%%%%%%%%: {EmailString}")

        email_content = {
            "subject": "سفارشات جدید!",
            "message": EmailString,
            "to_email": email.emailAddr,
        }
        requests.post(f"{BASE_URL}/API/send_email/", email_content)

        print("creation has been completed !!!!!!!!!!!!!!!!!!!!!!!!")

        # Delete verToBeDeleted before returning success
        verToBeDeleted.delete()

        return JsonResponse({"status": 200})
    except Exception as e:
        print(f"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! Failure {e}")
        return JsonResponse({"status": 199, "ERR": str(e)})


@csrf_exempt
def Login(request):
    if request.method == "POST":
        data = json.loads(request.body)
        username = data["username"]
        password = data["password"]

        user = authenticate(request, username=username, password=password)
        if user is not None:
            token = create_jwt(user.id)
            return JsonResponse({"status": 200, "sessionId": token})

        return JsonResponse({"status": 199})


@csrf_exempt
def LogOut(request):
    logout(request)
    return JsonResponse({"status": 200})


@csrf_exempt
def registerUser(request):
    try:
        data = json.loads(request.body)
        username = data["mobile"]
        email = data["email"]  # Added email
        password = data["password"]
        verCode = data["verCode"]

        verObj = temporaryPssKey.objects.filter(value=verCode)
        if not verObj.exists():
            return JsonResponse({"status": "verifection_failed"})

        verObj.latest("id").delete()  # Delete the latest matching verification code

        try:
            u = User.objects.create_user(
                username=username,
                email=email,  # Set email on User model
                password=password,
            )
            p = profile.objects.create(
                user=u,
                firstName=data["firstname"],
                lastName=data["lastname"],
            )
        except Exception as e:
            print(f"Error creating user: {e}")
            return JsonResponse({"status": "DUP"})

        print(f"User created: username={username}, email={email}")
        return JsonResponse({"status": 200})

    except Exception as e:
        print(f"Error in registerUser: {e}")
        return JsonResponse({"status": "err", "message": str(e)})


@csrf_exempt
@require_POST
def update_profile(request):
    user = get_authenticated_user(request)
    if not user:
        return JsonResponse({"status": "no", "message": "Unauthorized"}, status=401)

    try:
        p = profile.objects.get(user=user)
        data = request.POST
        files = request.FILES

        # Update User fields
        if "email" in data and data["email"]:
            user.email = data["email"]
        if "password" in data and data["password"]:
            user.password = make_password(data["password"])
        user.save()

        # Update profile fields
        if "firstName" in data:
            p.firstName = data["firstName"] if data["firstName"] else None
        if "lastName" in data:
            p.lastName = data["lastName"] if data["lastName"] else None
        if "bio" in data:
            p.bio = data["bio"] if data["bio"] else None
        if "profile_photo" in files:
            p.profile_photo = files["profile_photo"]
        if "resume" in files:
            p.resume = files["resume"]
        p.save()

        return JsonResponse(
            {
                "status": "ok",
                "message": "پروفایل با موفقیت به‌روزرسانی شد",
                "data": p.dataOut(),
            }
        )
    except profile.DoesNotExist:
        return JsonResponse({"status": "no", "message": "پروفایل یافت نشد"}, status=404)
    except Exception as e:
        return JsonResponse({"status": "no", "message": str(e)}, status=400)


@csrf_exempt
def delOrd(request):
    try:
        data = json.loads(request.body)

        ordId = data["ordId"]

        o = Ord.objects.get(id=ordId)

        o.status = "C"

        o.save()

        return JsonResponse({"status": 200})
    except:
        return JsonResponse({"status": "ERR"})


@csrf_exempt
def submitAComment(request):
    user = get_authenticated_user(request)
    if not user:
        return JsonResponse({"status": "no", "message": "Unauthorized"}, status=401)

    data = json.loads(request.body)

    try:
        p = profile.objects.get(user=user)  # profile linked to this user
        event = Event.objects.get(id=data["eventId"])
        eventToProf = eventToProfwhore.objects.filter(prof__user=user, event=event)

        comment.objects.create(author=p, message=data["message"], Event=event)
        return JsonResponse({"status": 200})

    except Exception as e:
        return JsonResponse({"status": str(e)})

    return JsonResponse({"status": 199})


@csrf_exempt
def getComments(request):
    try:
        data = json.loads(request.body)
        print(data["djangoId"])
        c = list(
            filter(
                lambda x: x.Event.id == data["djangoId"], list(comment.objects.all())
            )
        )
        return JsonResponse(
            {"status": 200, "data": list(map(lambda x: x.giveData(), c))}
        )

    except Exception as e:
        return JsonResponse({"status": 199, "err": str(e)})


@csrf_exempt
def getMainMenu_first(request):
    obj = mainTableFirstPic.objects.all()[0]
    return JsonResponse(
        {
            "status": 200,
            "imgUrl": request.build_absolute_uri(obj.image.url),
            "division": str(obj.div),
            "subDivision": str(obj.subDiv),
            "event": str(obj.event),
        }
    )


@csrf_exempt
def getMainMenu_Second(request):
    obj = mainSecond.objects.all()

    return JsonResponse(
        {
            "data": [
                {
                    "imgUrl": request.build_absolute_uri(i.image.url),
                    "division": str(i.div),
                    "subDivision": str(i.subDiv),
                    "event": str(i.event),
                }
                for i in obj
            ],
            "status": 200,
        }
    )


@csrf_exempt
def getMainMenu_Third(request):
    obj = mainThird.objects.all()

    return JsonResponse(
        {
            "data": [
                {
                    "imgUrl": request.build_absolute_uri(i.image.url),
                    "division": str(i.div),
                    "subDivision": str(i.subDiv),
                    "event": str(i.event),
                }
                for i in obj
            ],
            "status": 200,
        }
    )


@csrf_exempt
def getSubDivisions(request):
    d = list(subDivision.objects.all())

    print(f"data data data data data data {[i.name for i in d]}")

    return JsonResponse(
        {
            "status": 200,
            "data": [
                {"title": i.name, "imageUrl": request.build_absolute_uri(i.image.url)}
                for i in d
            ],
        }
    )


@csrf_exempt
def getArticles(request):
    try:
        a = Article.objects.all()
        a = list(a)
    except:
        return JsonResponse({"status": None})

    return JsonResponse(
        {
            "status": 200,
            "items": [
                {
                    "title": i.header,
                    "article": i.article,
                    "date": i.date,
                    "imageUrl": request.build_absolute_uri(i.image.url),
                    "publish": i.publish,
                }
                for i in a
                if i.publish == True
            ],
        }
    )


@csrf_exempt
def chaparOrder(request):
    data = json.loads(request.body)

    url = "https://app.krch.ir/v1/bulk_import"

    actual = {
        "user": {"username": "behsaye", "password": "66085"},
        "bulk": [
            {
                "cn": {
                    "reference": 123,
                    "date": "2019-05-13",
                    "assinged_pieces": data["pieces"],
                    "service": "1",
                    "payment_term": 0,
                    "weight": "1",
                    "content": "شیشه و سنگ",
                },
                "sender": {
                    "person": "ماهور",
                    "company": "پرده ماهور",
                    "city_no": "10866",
                    "telephone": "+9888288475",
                    "mobile": "989123181638",
                    "email": "sender@test.com",
                    "address": "آزمایشی فرستنده",
                    "postcode": "10770",
                },
                "receiver": {
                    "person": "آزمایشی گیرنده",
                    "company": "شرکت گیرنده",
                    "city_no": "10770",
                    "telephone": "+9888269464",
                    "mobile": "989034538660",
                    "email": "test@test.com",
                    "address": "آزمایشی گیرنده",
                    "postcode": "10770",
                },
            }
        ],
    }

    payload = {"input": f"""{str(actual)}"""}
    files = []
    headers = {}

    response = requests.request("POST", url, headers=headers, data=payload, files=files)

    print(response.text)


@csrf_exempt
def getChaparPrice(request):
    data = json.loads(request.body)

    dest = data["dest"]
    value = data["value"]
    print(
        f"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!{dest}"
    )
    actual = {
        "order": {
            "origin": "10925",
            "destination": dest,
            "method": "11",
            "value": value,
            "weight": "4",
        }
    }

    url = "https://api.krch.ir/v1/get_quote"

    payload = {"input": f"{json.dumps(actual)}"}
    files = []
    headers = {}

    response = requests.request("POST", url, headers=headers, data=payload, files=files)

    print("trying")
    print(response.text)
    print(type(response.text))

    out = json.loads(response.text)
    print(out)

    return JsonResponse(
        {
            "status": 200,
            "data": str(int(out["objects"]["order"]["price"]["fld_Total_Cost"]) / 10),
        }
    )


@csrf_exempt
def handler404(request, exception):
    return redirect("http://127.0.0.1:8000/404")
    return JsonResponse({"Srt": 200})


@csrf_exempt
@require_POST
def generatekeyCode(request):
    try:
        # Log the raw request body for debugging
        print(f"Request body: {request.body.decode('utf-8', errors='ignore')}")

        # Parse JSON body
        try:
            data = json.loads(request.body) if request.body else {}
        except json.JSONDecodeError as e:
            print(f"JSON decode error: {str(e)}")
            return JsonResponse({"status": "error", "message": "Invalid JSON format"}, status=400)

        # Validate email
        email_addr = data.get('email')
        if not email_addr:
            return JsonResponse({"status": "error", "message": "Email address is required"}, status=400)

        # Generate 6-digit code
        code = ''.join(str(random.randint(0, 9)) for _ in range(6))

        # Store code in temporaryPssKey model
        temp_pass = temporaryPssKey.objects.create(value=code)

        # Send email using Django's EmailMessage
        subject = "انجمن علمی | کد تائید ساخت حساب کاربری جدید"
        message = f"کد تائید: {temp_pass.value}"
        email = EmailMessage(
            subject=subject,
            body=message,
            from_email=settings.MAIL_FROM,  # Use MAIL_FROM from settings.py
            to=[email_addr],
            headers={"x-liara-tag": "verification-code"},
        )
        email.send()

        return JsonResponse({"status": "success", "message": "Verification code sent successfully"}, status=200)

    except temporaryPssKey.DoesNotExist:
        print("Error: Failed to create verification code")
        return JsonResponse({"status": "error", "message": "Failed to create verification code"}, status=500)
    except Exception as e:
        print(f"Error sending email: {str(e)}")
        return JsonResponse({"status": "error", "message": f"Failed to send email: {str(e)}"}, status=500)

@csrf_exempt
def userExistsTest(request):
    try:
        data = json.loads(request.body)
        userName = data["userName"]
        email = data.get("email")  # Added email check
        usrExstTstVar = User.objects.filter(username=userName)
        emailExstTstVar = User.objects.filter(email=email) if email else []

        if usrExstTstVar.exists() or emailExstTstVar.exists():
            return JsonResponse(
                {"status": "DUP", "message": "این شماره یا ایمیل قبلاً ثبت شده است"}
            )
        return JsonResponse({"status": "OK"})

    except Exception as e:
        print(f"Error in userExistsTest: {e}")
        return JsonResponse({"status": "err", "message": str(e)})


@csrf_exempt
def setServerCookie(request):
    data = json.loads(request.body)

    # try:
    #     sc = serverSideCookie.objects.all()[0]
    #     sc.data = json.dumps(data)
    #     print("cookie set")
    #     print(data)
    #     print(sc.data)
    #     return JsonResponse({"status":200,"data":json.loads(sc.data)["data"] })

    # except:
    prettyData = json.dumps(data, indent=4, sort_keys=True)

    Evaluate = serverSideCookie.objects.all()
    print("!!!!!!!!!!!!!!!!!!!!!!!!")
    for item in Evaluate:
        print(item.cookieVal)
        print(data["id"])
    print("!!!!!!!!!!!!!!!!!!!!!!!!")
    Evaluate = list(filter(lambda x: x.cookieVal == data["id"], Evaluate))

    if not (len(Evaluate) == 0):
        sc = Evaluate[-1]
        sc.data = prettyData
        sc.save()
    else:
        sc = serverSideCookie.objects.create(
            data=json.dumps(data), cookieVal=data["id"]
        )

    sc.viewData()
    print("cookie set")

    return JsonResponse(json.loads(sc.data)["data"])


@csrf_exempt
def getServerCookie(request):
    try:

        data = json.loads(request.body)

        cookieVal = data["id"]

        sc = list(
            filter(lambda x: x.cookieVal == cookieVal, serverSideCookie.objects.all())
        )

        retList = list(map(lambda x: json.loads(x.data), sc))[0]

        return JsonResponse(retList)

    except Exception as e:
        print("Cookie EXXXXXXXXXXXXXXXXXXEPTION", e)
        return JsonResponse({"status": 199})


@csrf_exempt
def deleteServerCookie(request):
    try:
        data = json.loads(request.body)

        sc = serverSideCookie.objects.filter(cookieVal=data["cookieVal"]).first()

        sc_deeper = json.loads(sc.data)["data"]["eventData"]

        itemToDelete = list(
            filter(lambda x: x["eliminationId"] == data["eliminationId"], sc_deeper)
        )[0]
        sc_deeper = list(
            filter(lambda x: x["eliminationId"] != data["eliminationId"], sc_deeper)
        )

        print(itemToDelete)
        ## Detecting the cost:
        costToMines = 0.0

        print("Cost To mines", costToMines)
        if sc:
            proceccedData = json.loads(sc.data)
            proceccedData["data"]["eventData"] = sc_deeper
            proceccedData["data"]["totalPrice"] -= costToMines
            sc.data = json.dumps(proceccedData, indent=4)
            retVal = json.loads(sc.data)
            sc.save()

            return JsonResponse(retVal)
        else:
            return JsonResponse({"status": 404, "message": "Cookie not found"})

    except Exception as e:
        print("Delete Cookie EXXXXXXXXXXXXXXXXXXEPTION", e)
        return JsonResponse(
            {"status": 199, "message": "An error occurred while deleting the cookie"}
        )


@csrf_exempt
@require_POST
def register_event(request, event_id):
    user = get_authenticated_user(request)
    if not user:
        return JsonResponse({"status": "no", "message": "Unauthorized"}, status=401)

    try:
        event = Event.objects.get(id=event_id)
    except Event.DoesNotExist:
        return JsonResponse({"status": "no", "message": "Event not found"}, status=404)

    obj, created = EventRegister.objects.get_or_create(user=user, event=event)
    if not created:
        return JsonResponse(
            {"status": "no", "message": "Already registered"}, status=400
        )

    return JsonResponse({"status": "ok", "message": "Registered successfully"})


def list_event_registrations(request):
    user = get_authenticated_user(request)
    if not user:
        return JsonResponse({"status": "no", "message": "Unauthorized"}, status=401)

    registrations = EventRegister.objects.select_related("user", "event").all()

    data = [
        {
            "user_id": r.user.id,
            "username": r.user.username,
            "event_id": r.event.id,
            "event_title": r.event.title,
            "date_registered": r.date_registered,
        }
        for r in registrations
    ]
    return JsonResponse({"status": "ok", "data": data})


@csrf_exempt
def get_authenticated_user_id(request):
    auth_header = request.META.get("HTTP_AUTHORIZATION", "")
    if not auth_header.startswith("Bearer "):
        return JsonResponse(
            {"status": "no", "message": "No token provided"}, status=401
        )

    token = auth_header.split(" ")[1]
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        user_id = payload.get("user_id")
        if not user_id:
            return JsonResponse(
                {"status": "no", "message": "Invalid token"}, status=401
            )

        try:
            User.objects.get(id=user_id)  # Verify user exists
            return JsonResponse({"status": "ok", "userId": user_id})
        except User.DoesNotExist:
            return JsonResponse(
                {"status": "no", "message": "User not found"}, status=404
            )
    except jwt.ExpiredSignatureError:
        return JsonResponse({"status": "no", "message": "Token expired"}, status=401)
    except jwt.InvalidTokenError:
        return JsonResponse({"status": "no", "message": "Invalid token"}, status=401)


# Assuming get_authenticated_user is defined in the same file or imported

# Assuming get_authenticated_user is defined in the same file or imported


@csrf_exempt
@require_GET
def getAllUserInfo(request):
    user = get_authenticated_user(request)
    if not user:
        return JsonResponse({"status": "no", "message": "Unauthorized"}, status=401)

    try:
        p = profile.objects.get(user=user)
        o = Ord.objects.filter(user=user).exclude(status="C")
        ords_data = [ord.dataOut() for ord in o]
        jsonOutPut = p.dataOut()
        try:
            jsonOutPut["profile_photo"] = request.build_absolute_uri(
                p.profile_photo.url
            )
        except:
            pass
        return JsonResponse(
            {**jsonOutPut, "ords": ords_data, "is_staff": user.is_staff}
        )
    except profile.DoesNotExist:
        return JsonResponse(
            {"status": "no", "message": "Profile not found"}, status=404
        )


@csrf_exempt
@require_GET
def my_registrations(request):
    user = get_authenticated_user(request)
    if not user:
        return JsonResponse({"status": "no", "message": "Unauthorized"}, status=401)

    registrations = EventRegister.objects.filter(user=user).select_related("event")
    data = [
        {
            "id": r.id,
            "event_title": r.event.title,
            "date_registered": r.date_registered.isoformat(),
        }
        for r in registrations
    ]
    return JsonResponse({"status": "ok", "data": data})


@csrf_exempt
@require_http_methods(["DELETE"])
def cancel_registration(request, registration_id):
    user = get_authenticated_user(request)
    if not user:
        return JsonResponse({"status": "no", "message": "Unauthorized"}, status=401)

    try:
        registration = EventRegister.objects.get(id=registration_id, user=user)
        registration.delete()
        return JsonResponse(
            {"status": "ok", "message": "Registration cancelled successfully"}
        )
    except ObjectDoesNotExist:
        return JsonResponse(
            {"status": "no", "message": "Registration not found or not yours"},
            status=404,
        )


@csrf_exempt
@require_http_methods(["POST"])
def LogOut(request):
    # Assuming this clears the session or invalidates the JWT
    return JsonResponse({"status": "ok", "message": "Logged out successfully"})


@csrf_exempt
def create_article(request):
    if request.method != "POST":
        return JsonResponse(
            {"status": 405, "message": "فقط درخواست‌های POST مجاز هستند"}
        )

    # Authenticate user using custom JWT
    user = get_authenticated_user(request)
    if not user:
        return JsonResponse(
            {"status": 401, "message": "توکن نامعتبر است یا منقضی شده است"}
        )

    try:
        # Extract data (ignore date)
        header = request.POST.get("header")
        article = request.POST.get("article")
        image = request.FILES.get("image")

        # Validate required fields
        if not header or not isinstance(header, str) or not header.strip():
            return JsonResponse(
                {
                    "status": 400,
                    "message": "عنوان مقاله الزامی است و باید رشته غیرخالی باشد",
                }
            )
        if not article or not isinstance(article, str) or not article.strip():
            return JsonResponse(
                {
                    "status": 400,
                    "message": "متن مقاله الزامی است و باید رشته غیرخالی باشد",
                }
            )

        # Debug data before saving
        print(
            "Data to save:",
            {"header": header, "article": article, "image": image, "publish": False},
        )

        # Create article (date is set by auto_now_add)
        article_instance = Article(
            header=header,
            article=article,
            image=image if image else None,
            publish=False,
        )
        article_instance.save()
        print("Saved article with ID:", article_instance.id)

        return JsonResponse(
            {
                "status": 200,
                "message": "مقاله با موفقیت ارسال شد و در انتظار بررسی است",
                "data": {
                    "id": article_instance.id,
                    "header": article_instance.header,
                    "date": article_instance.date.strftime("%Y-%m-%d"),
                    "publish": article_instance.publish,
                },
            }
        )

    except Exception as e:
        print("Error during save:", str(e))
        return JsonResponse({"status": 500, "message": f"خطا در سرور: {str(e)}"})


@csrf_exempt
def news_list(request):
    if request.method != "GET":
        return JsonResponse({"status": 405, "message": "فقط درخواست‌های GET مجاز هستند"})

    try:
        news_items = News.objects.all()
        data = [
            {
                "id": item.id,
                "title": item.title,
                "content": item.content,
                "author": item.author.username,
                "date": item.date.strftime("%Y-%m-%d"),
                "image": (
                    request.build_absolute_uri(item.image.url) if item.image else None
                ),
                "publish": item.publish,
            }
            for item in news_items
        ]

        return JsonResponse(
            {"status": 200, "message": "لیست اخبار با موفقیت دریافت شد", "data": data}
        )

    except Exception as e:
        print("Error in news_list:", str(e))
        return JsonResponse({"status": 500, "message": f"خطا در سرور: {str(e)}"})


@csrf_exempt
@require_POST
def submit_news_comment(request, news_id):
    user = get_authenticated_user(request)
    if not user:
        return JsonResponse({"status": 401, "message": "Unauthorized"})

    try:
        news = News.objects.get(id=news_id)
    except News.DoesNotExist:
        return JsonResponse({"status": 404, "message": "News not found"})

    try:
        data = json.loads(request.body)
        content = data.get("content")
    except json.JSONDecodeError:
        return JsonResponse({"status": 400, "message": "Invalid JSON"})

    print("Received content:", content)  # Debug log
    if not content:
        return JsonResponse({"status": 400, "message": "Content is required"})

    comment = NewsComment(user=user, news=news, content=content)
    comment.save()

    return JsonResponse(
        {
            "status": 200,
            "message": "Comment submitted successfully",
            "data": {
                "id": comment.id,
                "user": user.username,
                "date": comment.date.isoformat(),
                "content": comment.content,
                "approved": comment.approved,
            },
        }
    )


@csrf_exempt
@require_GET
def get_news_comments(request, news_id):
    try:
        news = News.objects.get(id=news_id)
    except News.DoesNotExist:
        return JsonResponse({"status": 404, "message": "News not found"})

    comments = NewsComment.objects.filter(news=news, approved=True).order_by("-date")
    data = [
        {
            "id": comment.id,
            "user": comment.user.username,
            "date": comment.date.isoformat(),
            "content": comment.content,
        }
        for comment in comments
    ]

    return JsonResponse(
        {"status": 200, "message": "Comments retrieved successfully", "data": data}
    )
