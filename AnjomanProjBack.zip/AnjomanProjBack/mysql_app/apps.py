from django.apps import AppConfig


class MysqlAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mysql_app'
