from django.http import HttpResponse, JsonResponse

from django.shortcuts import redirect
from suds.client import Client
import json
from django.views.decorators.csrf import csrf_exempt
from frontEnd.models import GenerateVeriifyKeyCode

MERCHANT_ID = "6ef1a0b0-d5c8-4bc3-898b-2dbfe0627178"  # Required

ZARINPAL_WEBSERVICE = (
    "https://www.zarinpal.com/pg/services/WebGate/wsdl"  # Required
)
amount = 5000  # Amount will be based on Toman  Required
description = "پول وده, پول زور ورده"  # Required
email = "user@userurl.ir"  # Optional
mobile = "09123456789"  # Optional
CallbackURL = "http://127.0.0.1:8000/verify/"
CallbackURL = "http://localhost:3000/verify/"
# CallbackURL = "https://pardehmahoor.ir/verify/"


@csrf_exempt
def pay(request):
    global amount
    data = json.loads(request.body)
    # MERCHANT_ID = data["MMERCHANT_ID"]
    amount = data["amount"]
    descriptionList = data["description"]
    description = data["description"]
    # email = data["email"]
    # mobile = data["mobile"]``
    # CallbackURL = data["CallbackURL"]


    client = Client(ZARINPAL_WEBSERVICE)
    result = client.service.PaymentRequest(
        MERCHANT_ID, amount, description, email, mobile, CallbackURL
    )
    if result.Status == 100:

        # return JsonResponse(
        #     {
        #         "status": 200,
        #         "url": 'https://sandbox.zarinpal.com/pg/StartPay/' + result.Authority,
        #         "auth": result.Authority,
        #     }
        # )
    
        return JsonResponse(
            {
                "status": 200,
                "url": f"https://www.zarinpal.com/pg/StartPay/{result.Authority}",
                "auth": result.Authority,
            }
        
        )

    else:
        return JsonResponse({"status": 199})


@csrf_exempt
def verify(request):
    ver = GenerateVeriifyKeyCode.objects.create()
    # return JsonResponse(
    #         {
    #             "status": 200,
    #             "url": f"http://localhost:3000/callBack/200/{str(ver.key)}",

    #         }
    # )

    # return redirect(f"http://localhost:3000/callBack/200/{str(ver.key)}")
    client = Client(ZARINPAL_WEBSERVICE)
    if request.GET.get("Status") == "OK":
        result = client.service.PaymentVerification(
            MERCHANT_ID, request.GET["Authority"], amount
        )

        print(f"{result.Status }&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")

        if result.Status == 100 or result.Status == 200 :
            ver = GenerateVeriifyKeyCode.objects.create()   

            # return redirect(f"http://127.0.0.1:8000/callBack/200/{str(ver.key)}")
            return redirect(f"http://localhost:3000/callBack/200/{str(ver.key)}")
            return redirect(f"https://pardehmahoor.ir/callBack/200/{str(ver.key)}")
        
        elif result.Status == 101:
            # return redirect(f"http://127.0.0.1:8000/callBack/101/nothing")
            return redirect(f"http://localhost:3000/callBack/101/nothing")
            return redirect(f"https://pardehmahoor.ir/callBack/101/nothing")

        
        else:
            # return redirect(f"http://127.0.0.1:8000/callBack/199/nothing")
            return redirect(f"http://localhost:3000/callBack/199/nothing")
            return redirect(f"https://pardehmahoor.ir/callBack/199/nothing")

    else:
        # return redirect(f"http://127.0.0.1:8000/callBack/199/nothing")
        return redirect(f"http://localhost:3000/callBack/199/nothing")
        return redirect(f"https://pardehmahoor.ir/callBack/199/nothing")

